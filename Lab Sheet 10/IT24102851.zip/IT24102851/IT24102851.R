setwd("C:\\Users\\User\\Downloads\\IT24102851")

#Part 01
customers <- c(55, 62, 43, 46, 50)
chisq.test(customers, p = rep(1/5, 5))

#Part 02
housetasks <- read.table("http://www.sthda.com/sthda/RDoc/data/housetasks.txt",
                         header = TRUE, row.names = 1)
housetasks
chisq.test(housetasks)
